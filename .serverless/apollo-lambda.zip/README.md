Steps to run this project:

1. Run `npm i` command
2. Setup database settings inside `ormconfig.json` file
3. Install docker, docker-compose
4. Run `docker-compose up -D`
5. Run `npm start` command
